﻿// conv2D.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "conv2D.h"


int main()
{
    conv2();
    //dev_conv2();
    //dev_conv2_fp16();
    //dev_conv2_mk();
    return 0;
}