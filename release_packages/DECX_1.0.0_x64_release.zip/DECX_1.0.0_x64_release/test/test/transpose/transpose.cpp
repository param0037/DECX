﻿// transpose.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#pragma comment(lib, "../../../bin/x64/DECX_CUDA.lib")
#pragma comment(lib, "../../../bin/x64/DECX_cpu.lib")
#pragma comment(lib, "../../../bin/x64/Image_IO_GUI.lib")
#include "../../../APIs/DECX.h"
#include <iostream>
#include <iomanip>
#include "../utils/printf.h"

using namespace std;

template <typename T>
void transpose()
{
    de::InitCuda();

    de::Matrix<T>& src = de::CreateMatrixRef<T>(1000, 2000, 0);
    de::GPU_Matrix<T>& dev_src = de::CreateGPUMatrixRef<T>(1000, 2000);
    de::GPU_Matrix<T>& dev_dst = de::CreateGPUMatrixRef<T>();

    for (int i = 0; i < src.Height(); ++i) {
        for (int j = 0; j < src.Width(); ++j) {
            src.index(i, j) = i;
        }
    }
    cout << "Original matrix : \n";
    print_square<T>(&src, src.Height() - 10, src.Height(), src.Width() - 10, src.Width());

    dev_src.Load_from_host(src);

    de::cuda::Transpose(dev_src, dev_dst);

    de::Matrix<T>& dst = de::CreateMatrixRef<T>(dev_dst.Width(), dev_dst.Height(), 0);

    dev_dst.Load_to_host(dst);

    cout << "Transposed matrix : \n";
    print_square<T>(&dst, dst.Height() - 10, dst.Height(), dst.Width() - 10, dst.Width());

    dev_src.release();
    dev_dst.release();

    src.release();
    dst.release();

    de::cuda::DECX_CUDA_exit();
}


int main()
{
    transpose<double>();
    return 0;
}