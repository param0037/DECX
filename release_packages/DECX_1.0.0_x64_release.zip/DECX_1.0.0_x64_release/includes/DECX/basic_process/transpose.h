/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _TRANSPOSE_H_
#define _TRANSPOSE_H_

#include "../basic.h"
#include "../classes/all_classes.h"

namespace de
{
    namespace cuda
    {
        _DECX_API_ de::DH Transpose(GPU_Matrix<float>& src, GPU_Matrix<float>& dst);


        _DECX_API_ de::DH Transpose(GPU_Matrix<int>& src, GPU_Matrix<int>& dst);


        _DECX_API_ de::DH Transpose(GPU_Matrix<double>& src, GPU_Matrix<double>& dst);


        _DECX_API_ de::DH Transpose(GPU_Matrix<de::Half>& src, GPU_Matrix<de::Half>& dst);


        _DECX_API_ de::DH Transpose(GPU_Matrix<de::CPf>& src, GPU_Matrix<de::CPf>& dst);
    }
}

#endif