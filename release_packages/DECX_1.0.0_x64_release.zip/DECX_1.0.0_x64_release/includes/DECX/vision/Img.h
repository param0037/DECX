/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _IMG_H_
#define _IMG_H_

#include "../basic.h"

namespace de
{
	namespace vis
	{
		enum ImgConstructType
		{
			DE_UC1 = 1,
			DE_UC3 = 3,
			DE_UC4 = 4,
			DE_IMG_DEFAULT = 5,
			DE_IMG_4_ALIGN = 6
		};

		class _DECX_API_ Img
		{
		public:
			Img() {}

			virtual uint Width() { return 0; }

			virtual uint Height() { return 0; }

			virtual uchar* Ptr(const uint row, const uint col) {
				uchar* ptr = NULL;
				return ptr;
			}

			virtual void release() {
				return;
			}
		};
	}

	namespace vis
	{
		enum ImgChannelMergeType
		{
			BGR_to_Gray = 0,
			Preserve_B = 1,
			Preserve_G = 2,
			Preserve_R = 3,
			Preserve_Alpha = 4,
			RGB_mean = 5,
		};

		_DECX_API_ de::DH merge_channel(de::vis::Img& src, de::vis::Img& dst, const int flag);


		_DECX_API_ de::vis::Img* CreateImgPtr(const uint width, const uint height, const int flag);


		_DECX_API_ de::vis::Img* CreateImgPtr();


		_DECX_API_ de::vis::Img& CreateImgRef(const uint width, const uint height, const int flag);


		_DECX_API_ de::vis::Img& CreateImgRef();


		_DECX_API_ de::DH merge_channel(de::vis::Img& src, de::vis::Img& dst, const int flag);
	}
}


#endif