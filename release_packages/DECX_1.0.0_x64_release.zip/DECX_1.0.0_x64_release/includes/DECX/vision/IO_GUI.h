/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _IO_GUI_H_
#define _IO_GUI_H_

namespace de
{
	namespace vis
	{

		_DECX_API_ void ShowImage(de::vis::Img& src, const wchar_t* window_name);


		_DECX_API_ void Wait();


		_DECX_API_ de::DH ReadImage(const wchar_t* file_path, de::vis::Img& src);


		_DECX_API_ de::DH ReadImage(std::string file_path, de::vis::Img& src);
	}
}

#endif