/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _NLM_H_
#define _NLM_H_

#include "../basic.h"
#include "Img.h"

namespace de
{
    namespace vis {
        namespace cuda {
            _DECX_API_ de::DH NLM_RGB(Img& src, Img& dst, uint search_window_radius, uint template_window_radius, float h);


            _DECX_API_ de::DH NLM_RGB_keep_alpha(Img& src, Img& dst, uint search_window_radius, uint template_window_radius, float h);


            _DECX_API_ de::DH NLM_Gray(Img& src, Img& dst, uint search_window_radius, uint template_window_radius, float h);
        }
    }
}

#endif