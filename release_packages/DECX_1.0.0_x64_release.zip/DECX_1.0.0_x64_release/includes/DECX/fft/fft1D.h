#ifndef _FFT1D_H_
#define _FFT1D_H_

#include "../basic.h"
#include "../classes/Vector.h"
#include "../classes/class_utils.h"


namespace de
{
	namespace fft
	{
		_DECX_API_ de::DH FFT1D_R2C_f(de::Vector<float>& src, de::Vector<de::CPf>& dst);


		_DECX_API_ de::DH FFT1D_C2C_f(de::Vector<de::CPf>& src, de::Vector<de::CPf>& dst);


		_DECX_API_ de::DH IFFT1D_C2R_f(de::Vector<de::CPf>& src, de::Vector<float>& dst);


		_DECX_API_ de::DH IFFT1D_C2C_f(de::Vector<de::CPf>& src, de::Vector<de::CPf>& dst);
	}
}


#endif