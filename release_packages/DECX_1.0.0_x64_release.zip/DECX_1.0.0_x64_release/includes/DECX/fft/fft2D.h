#ifndef _FFT2D_H_
#define _FFT2D_H_

#include "../basic.h"
#include "../classes/Matrix.h"


namespace de
{
	namespace fft
	{
		_DECX_API_ de::DH FFT2D_R2C_f(de::Matrix<float>& src, de::Matrix<de::CPf>& dst);


		_DECX_API_ de::DH FFT2D_C2C_f(de::Matrix<de::CPf>& src, de::Matrix<de::CPf>& dst);



		_DECX_API_ de::DH IFFT2D_C2R_f(de::Matrix<de::CPf>& src, de::Matrix<float>& dst);


		_DECX_API_ de::DH IFFT2D_C2C_f(de::Matrix<de::CPf>& src, de::Matrix<de::CPf>& dst);



	}
}


#endif