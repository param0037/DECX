/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#pragma once

#ifndef _MATRIXARRAY_H_
#define _MATRIXARRAY_H_

#include "../basic.h"

namespace de
{
	/*
	* This class is for matrices array, the matrices included share the same sizes, and store
	* one by one in the memory block, without gap; Compared with de::Tensor<T>, the channel "z"
	* is separated.
	*/
	template <typename T>
	class _DECX_API_ MatrixArray
	{
	public:
		uint ArrayNumber;


		virtual uint Width() = 0;


		virtual uint Height() = 0;


		virtual uint MatrixNumber() = 0;


		virtual T& index(uint row, uint col, size_t _seq) = 0;


		virtual de::MatrixArray<T>& operator=(de::MatrixArray<T>& src) = 0;


		virtual void release() = 0;
	};


	template <typename T>
	_DECX_API_ de::MatrixArray<T>& CreateMatrixArrayRef();


	template <typename T>
	_DECX_API_ de::MatrixArray<T>* CreateMatrixArrayPtr();


	template <typename T>
	_DECX_API_ de::MatrixArray<T>& CreateMatrixArrayRef(uint width, uint height, uint MatrixNum, const int flag);


	template <typename T>
	_DECX_API_ de::MatrixArray<T>* CreateMatrixArrayPtr(uint width, uint height, uint MatrixNum, const int flag);
}

#endif