/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#pragma once

#ifndef _ALL_CLASSES_H_
#define _ALL_CLASSES_H_

#include "Vector.h"
#include "Matrix.h"
#include "Tensor.h"
#include "MatrixArray.h"

#include "GPU_Vector.h"
#include "GPU_Matrix.h"
#include "GPU_Tensor.h"
#include "GPU_MatrixArray.h"

#endif