/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#pragma once

#ifndef _GPU_MATRIX_H_
#define _GPU_MATRIX_H_

#include "../basic.h"

namespace de
{
	template<typename T>
	class _DECX_API_ GPU_Matrix
	{
	public:
		GPU_Matrix() {}


		virtual uint Width() = 0;


		virtual uint Height() = 0;


		virtual size_t TotalBytes() = 0;


		virtual void Load_from_host(de::Matrix<T>& src) = 0;


		virtual void Load_to_host(de::Matrix<T>& dst) = 0;


		virtual void release() = 0;


		virtual de::GPU_Matrix<T>& operator=(de::GPU_Matrix<T>& src) = 0;


		~GPU_Matrix() {}

		/*GPU_Matrix() {}


		virtual uint Width() { return 0; }


		virtual uint Height() { return 0; }


		virtual size_t TotalBytes() { return 0; }


		virtual void Load_from_host(de::Matrix<T>& src) { return; }


		virtual void Load_to_host(de::Matrix<T>& dst) { return; }


		virtual void release() { return; }


		virtual void reference(de::GPU_Matrix<T>& dst) { return; }


		~GPU_Matrix() {}*/
	};


	template <typename T>
	_DECX_API_ de::GPU_Matrix<T>& CreateGPUMatrixRef();


	template <typename T>
	_DECX_API_ de::GPU_Matrix<T>* CreateGPUMatrixPtr();


	template <typename T>
	_DECX_API_ de::GPU_Matrix<T>& CreateGPUMatrixRef(const uint width, const uint height);

	template <typename T>
	_DECX_API_ de::GPU_Matrix<T>* CreateGPUMatrixPtr(const uint width, const uint height);


	/*template <typename T>
	de::DH CreateGPUMatrixRef(de::GPU_Matrix<T>& dst);

	template <typename T>
	de::DH CreateGPUMatrixPtr(de::GPU_Matrix<T>* dst);


	template <typename T>
	de::DH CreateGPUMatrixRef(de::GPU_Matrix<T>& dst, const uint width, const uint height);

	template <typename T>
	de::DH CreateGPUMatrixPtr(de::GPU_Matrix<T>* dst, const uint width, const uint height);*/
}

#endif