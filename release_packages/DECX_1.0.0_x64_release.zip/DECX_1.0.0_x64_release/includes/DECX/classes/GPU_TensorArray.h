/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _GPU_TENSORARRAY_H_
#define _GPU_TENSORARRAY_H_


#include "../basic.h"


namespace de
{
    template <typename T>
    class _DECX_API_ GPU_TensorArray
    {
    public:
        GPU_TensorArray() {}


        virtual uint Width() = 0;


        virtual uint Height() = 0;


        virtual uint Depth() = 0;


        virtual uint TensorNum() = 0;


        virtual void Load_from_host(de::TensorArray<T>& src) = 0;


        virtual void Load_to_host(de::TensorArray<T>& src) = 0;


        virtual de::GPU_TensorArray<T>& operator=(de::GPU_TensorArray<T>& src) = 0;


        virtual void release() = 0;
    };
}


namespace de
{
    template <typename T>
    _DECX_API_ de::GPU_TensorArray<T>& CreateGPUTensorArrayRef();


    template <typename T>
    _DECX_API_ de::GPU_TensorArray<T>* CreateGPUTensorArrayPtr();


    template <typename T>
    _DECX_API_ de::GPU_TensorArray<T>& CreateGPUTensorArrayRef(const uint width, const uint height, const uint depth, const uint tensor_num);


    template <typename T>
    _DECX_API_ de::GPU_TensorArray<T>* CreateGPUTensorArrayPtr(const uint width, const uint height, const uint depth, const uint tensor_num);
}


#endif