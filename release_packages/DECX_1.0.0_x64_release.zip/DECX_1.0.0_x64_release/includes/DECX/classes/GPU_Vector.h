/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#pragma once

#ifndef _GPU_VECTOR_H_
#define _GPU_VECTOR_H_

#include "../basic.h"

namespace de
{
	template <typename T>
	class _DECX_API_ GPU_Vector
	{
	public:
		GPU_Vector() {}

		virtual size_t Len() = 0;

		virtual void load_from_host(de::Vector<T>& src) = 0;

		virtual void load_to_host(de::Vector<T>& dst) = 0;

		virtual void release() = 0;

		~GPU_Vector() {}
	};


	template <typename T>
	_DECX_API_ de::GPU_Vector<T>& CreateGPUVectorRef(const size_t length);


	template <typename T>
	_DECX_API_ de::GPU_Vector<T>* CreateGPUVectorPtr(const size_t length);
}

#endif