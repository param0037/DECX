/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _TENSORARRAY_H_
#define _TENSORARRAY_H_

#include "../basic.h"

namespace de
{
	template <typename T>
	class _DECX_API_ TensorArray
	{
	public:
		TensorArray() {}


		virtual uint Width() = 0;


		virtual uint Height() = 0;


		virtual uint Depth() = 0;


		virtual uint TensorNum() = 0;


		virtual T& index(const int x, const int y, const int z, const int tensor_id) = 0;


		virtual de::TensorArray<T>& operator=(de::TensorArray<T>& src) = 0;


		virtual void release() = 0;
	};
}


namespace de
{
	template <typename T>
	_DECX_API_ de::TensorArray<T>& CreateTensorArrayRef();


	template <typename T>
	_DECX_API_ de::TensorArray<T>* CreateTensorArrayPtr();


	template <typename T>
	_DECX_API_ de::TensorArray<T>& CreateTensorArrayRef(const uint width, const uint height, const uint depth, const uint tensor_num, const int store_type);


	template <typename T>
	_DECX_API_ de::TensorArray<T>* CreateTensorArrayPtr(const uint width, const uint height, const uint depth, const uint tensor_num, const int store_type);
}


#endif