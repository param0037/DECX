/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#pragma once


#ifndef _VECTOR_H_
#define _VECTOR_H_

#include "../basic.h"

namespace de
{
	template<typename T>
	class _DECX_API_ Vector
	{
	public:
		Vector() {}

		virtual uint Len() = 0;

		virtual T& index(size_t index) = 0;


		virtual void release() = 0;


		virtual ~Vector() {}
	};


	template <typename T>
	_DECX_API_ de::Vector<T>& CreateVectorRef(size_t len, const int flag);



	template <typename T>
	_DECX_API_ de::Vector<T>* CreateVectorPtr(size_t len, const int flag);


	template <typename T>
	_DECX_API_ de::Vector<T>& CreateVectorRef();


	template <typename T>
	_DECX_API_ de::Vector<T>* CreateVectorPtr();
}

#endif