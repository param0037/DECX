/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _MATRIX_H_
#define _MATRIX_H_

#include "../basic.h"
#include "class_utils.h"


/**
* in host, allocate page-locaked memory in 8-times both on width and height
* ensure the utilization of __m128 and __m256, as well as multi threads
*/
namespace de 
{
	template<typename T>
	class _DECX_API_ Matrix
	{
	public:
		Matrix() {}


		virtual uint Width() = 0;


		virtual uint Height() = 0;


		virtual size_t TotalBytes() = 0;


		/* return the reference of the element in the matrix, which locates on specific row and colume
		* \params row -> where the element locates on row
		* \params col -> where the element locates on colume
		*/
		virtual T& index(const int row, const int col) = 0;


		virtual void release() = 0;


		virtual de::Matrix<T>& operator=(de::Matrix<T>& src) = 0;


		~Matrix() {}
	};


	template <typename T>
	_DECX_API_ de::Matrix<T>* CreateMatrixPtr();


	template <typename T>
	_DECX_API_ de::Matrix<T>& CreateMatrixRef();


	template <typename T>
	_DECX_API_ de::Matrix<T>* CreateMatrixPtr(const uint _width, const uint _height, const int store_type);


	template <typename T>
	_DECX_API_ de::Matrix<T>& CreateMatrixRef(const uint _width, const uint _height, const int store_type);
}

#endif