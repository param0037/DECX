/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _DOT_H_
#define _DOT_H_

#include "../classes/Vector.h"
#include "../classes/Matrix.h"
#include "../classes/GPU_Vector.h"


namespace de
{
    namespace cuda
    {
        _DECX_API_ de::DH Dot(de::Vector<float>& A, de::Vector<float>& B, float* res);


        _DECX_API_ de::DH Dot(de::GPU_Vector<float>& A, de::GPU_Vector<float>& B, float* res);


        _DECX_API_ de::DH Dot(de::Matrix<float>& A, de::Matrix<float>& B, float* res);


        _DECX_API_ de::DH Dot(de::GPU_Matrix<float>& A, de::GPU_Matrix<float>& B, float* res);
    }
}


#endif