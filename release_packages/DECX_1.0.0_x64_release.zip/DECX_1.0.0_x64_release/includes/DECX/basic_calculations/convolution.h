/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/


#ifndef _CONVOLUTION_H_
#define _CONVOLUTION_H_

#include "../basic.h"
#include "../classes/Matrix.h"
#include "../classes/GPU_Matrix.h"
#include "../classes/MatrixArray.h"
#include "../classes/GPU_MatrixArray.h"
#include "../classes/TensorArray.h"


namespace de
{
	enum conv_property
	{
		de_conv_no_compensate = 0,
		de_conv_zero_compensate = 1
	};

	namespace cuda
	{
		_DECX_API_ de::DH Conv2(de::Matrix<float>& src, de::Matrix<float>& kernel, de::Matrix<float>& dst, const uint flag);



		_DECX_API_ de::DH Conv2(de::Matrix<de::Half>& src, de::Matrix<de::Half>& kernel, de::Matrix<de::Half>& dst, const uint flag);



		_DECX_API_ de::DH Conv2(de::GPU_Matrix<float>& src, de::GPU_Matrix<float>& kernel, de::GPU_Matrix<float>& dst, const uint flag);



		_DECX_API_ de::DH Conv2(de::GPU_Matrix<de::Half>& src, de::GPU_Matrix<de::Half>& kernel, de::GPU_Matrix<de::Half>& dst, const uint flag);



		_DECX_API_ de::DH Conv2_MK_im2col(de::Tensor<float>& src, de::TensorArray<float>& kernel, de::Tensor<float>& dst, const int flag);



		_DECX_API_ de::DH Conv2(de::GPU_Matrix<float>* src, de::GPU_Matrix<float>* kernel, de::GPU_Matrix<float>* dst, const uint flag);



		_DECX_API_ de::DH Conv2_single_kernel(de::MatrixArray<float>& src, de::Matrix<float>& kernel, de::MatrixArray<float>& dst, const int flag);



		_DECX_API_ de::DH Conv2_single_kernel(de::MatrixArray<de::Half>& src, de::Matrix<de::Half>& kernel, de::MatrixArray<de::Half>& dst, const int flag);



		_DECX_API_ de::DH Conv2_multi_kernel(de::MatrixArray<float>& src, de::MatrixArray<float>& kernel, de::MatrixArray<float>& dst, const int flag);



		_DECX_API_ de::DH Conv2_multi_kernel(de::MatrixArray<de::Half>& src, de::MatrixArray<de::Half>& kernel, de::MatrixArray<de::Half>& dst, const int flag);


		// on device
		_DECX_API_ de::DH Conv2_single_kernel(de::GPU_MatrixArray<float>& src, de::GPU_Matrix<float>& kernel, de::GPU_MatrixArray<float>& dst, const int flag);



		_DECX_API_ de::DH Conv2_multi_kernel_accu(de::MatrixArray<de::Half>& src, de::MatrixArray<de::Half>& kernel, de::MatrixArray<de::Half>& dst, const int flag);



		_DECX_API_ de::DH Conv2_multi_kernel(de::GPU_MatrixArray<float>& src, de::GPU_MatrixArray<float>& kernel, de::GPU_MatrixArray<float>& dst, const int flag);



		_DECX_API_ de::DH Conv2_single_kernel(de::GPU_MatrixArray<de::Half>& src, de::GPU_Matrix<de::Half>& kernel, de::GPU_MatrixArray<de::Half>& dst, const int flag);



		_DECX_API_ de::DH Conv2_multi_kernel(de::GPU_MatrixArray<de::Half>& src, de::GPU_MatrixArray<de::Half>& kernel, de::GPU_MatrixArray<de::Half>& dst, const int flag);



		_DECX_API_ de::DH Conv2_multi_kernel(de::GPU_MatrixArray<de::Half>& src, de::GPU_MatrixArray<de::Half>& kernel, de::GPU_MatrixArray<de::Half>& dst, const int flag);
	}
}

#endif