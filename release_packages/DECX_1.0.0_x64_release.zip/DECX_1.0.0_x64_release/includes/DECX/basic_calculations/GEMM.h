/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#ifndef _GEMM_H_
#define _FEMM_H_

#include "../classes/GPU_Matrix.h"
#include "../classes/Matrix.h"

namespace de
{
	_DECX_API_ de::Half Float2Half(const float& __x);


	_DECX_API_ float Half2Float(const de::Half& __x);

	namespace cuda
	{
		_DECX_API_ de::DH GEMM(de::Matrix<float>& A, de::Matrix<float>& B, de::Matrix<float>& dst);


		_DECX_API_ de::DH GEMM(de::Matrix<float>& A, de::Matrix<float>& B, de::Matrix<float>& C, de::Matrix<float>& dst);


		_DECX_API_ de::DH GEMM(de::Matrix<de::Half>& A, de::Matrix<de::Half>& B, de::Matrix<de::Half>& dst);


		_DECX_API_ de::DH GEMM(de::Matrix<de::Half>& A, de::Matrix<de::Half>& B, de::Matrix<de::Half>& C, de::Matrix<de::Half>& dst);


		// --------------------------------------------- pure GPU -----------------------------------------------------------

		_DECX_API_ de::DH GEMM(de::GPU_Matrix<float>& A, de::GPU_Matrix<float>& B, de::GPU_Matrix<float>& dst);


		_DECX_API_ de::DH GEMM(de::GPU_Matrix<de::Half>& A, de::GPU_Matrix<de::Half>& B, de::GPU_Matrix<de::Half>& dst);


		_DECX_API_ de::DH GEMM(de::GPU_Matrix<float>& A, de::GPU_Matrix<float>& B, de::GPU_Matrix<float>& C, de::GPU_Matrix<float>& dst);


		_DECX_API_ de::DH GEMM(de::GPU_Matrix<de::Half>& A, de::GPU_Matrix<de::Half>& B, de::GPU_Matrix<de::Half>& C, de::GPU_Matrix<de::Half>& dst);


		_DECX_API_ de::DH GEMM_Long_Lr(de::GPU_Matrix<float>& A, de::GPU_Matrix<float>& B, de::GPU_Matrix<float>& dst);
	}

	namespace cpu
	{
		_DECX_API_ de::DH sgemm(de::Matrix<float>& A, de::Matrix<float>& B, de::Matrix<float>& dst);
	}
}

#endif