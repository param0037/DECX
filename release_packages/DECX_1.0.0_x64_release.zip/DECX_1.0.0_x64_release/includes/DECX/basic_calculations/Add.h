/**
*	---------------------------------------------------------------------
*	Author : Wayne Anderson
*   Date   : 2021.04.16
*	---------------------------------------------------------------------
*	This is a part of the open source program named "DECX", copyright c Wayne,
*	2021.04.16
*/

#pragma once

#include "../classes/all_classes.h"

#ifndef _ADD_H_
#define _ADD_H_

namespace de
{
	namespace cuda
	{
		template <typename T>
		_DECX_API_  de::DH Add(de::GPU_Matrix<T>& A, de::GPU_Matrix<T>& B, de::GPU_Matrix<T>& dst);


		template <typename T>
		_DECX_API_  de::DH Add(de::GPU_Matrix<T>& src, T __x, de::GPU_Matrix<T>& dst);


		template <typename T>
		_DECX_API_  de::DH Add(de::GPU_Vector<T>& A, de::GPU_Vector<T>& B, de::GPU_Vector<T>& dst);



		template <typename T>
		_DECX_API_  de::DH Add(de::GPU_Vector<T>& src, T __x, de::GPU_Vector<T>& dst);
	}
}

#endif